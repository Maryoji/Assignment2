function i = coordinate(x,y,nx)
% COORDINATE maps x,y coordinates.

i = (y-1).*nx + x;

end
